<?php
class Post
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function getAllPosts()
    {
        $sql = "SELECT posts.id, posts.title, posts.description, posts.date, users.username
                FROM posts
                JOIN users ON posts.id_author = users.id";
        $result = mysqli_query($this->conn, $sql);

        if (!$result) {
            throw new Exception("SQL Error: " . mysqli_error($this->conn));
        }

        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
}
