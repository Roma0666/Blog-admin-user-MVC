<?php

class AdminTag
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function getAllPosts()
    {
        $records_per_page = 5;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $records_per_page;

        $searchQuery = '';
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $searchQuery = $conn->real_escape_string($_GET['search']);
            $sql = "SELECT * FROM tags WHERE title LIKE '%$searchQuery%' OR description LIKE '%$searchQuery%' LIMIT $records_per_page OFFSET $offset";
        } else {
            $sql = "SELECT * FROM tags LIMIT $records_per_page OFFSET $offset";
        }

        $result = $conn->query($sql);

        $total_result_sql = "SELECT COUNT(*) AS total FROM tags";
        if (!empty($searchQuery)) {
            $total_result_sql = "SELECT COUNT(*) AS total FROM tags WHERE title LIKE '%$searchQuery%' OR description LIKE '%$searchQuery%'";
        }
        $total_result = $conn->query($total_result_sql);
        $total_row = $total_result->fetch_assoc();
        $total_records = $total_row['total'];
        $total_pages = ceil($total_records / $records_per_page);
    }
}