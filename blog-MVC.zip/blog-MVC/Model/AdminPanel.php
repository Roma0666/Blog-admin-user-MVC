<?php

class AdminPanel
{

    public function isLoggedIn()
    {
        return isset($_SESSION['user_id']);
    }

    public function getUserRole()
    {
        return isset($_SESSION['role']) ? $_SESSION['role'] : '';
    }
}