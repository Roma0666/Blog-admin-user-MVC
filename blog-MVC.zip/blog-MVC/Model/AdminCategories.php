<?php

class AdminCategories
{

}