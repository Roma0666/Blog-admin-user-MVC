<?php

class PostPage
{
    public function getAllPosts(){
        require __DIR__ . "/../db.php";
        $sql = "SELECT * FROM tags";
        $resultTags = $conn->query($sql);
        $tags = [];
        if ($resultTags->num_rows > 0) {
            while ($row = $resultTags->fetch_assoc()) {
                $tags[] = $row;
            }
        }

        $sqlCategories = "SELECT * FROM categories";
        $resultCategories = $conn->query($sqlCategories);
        $categories = [];
        if ($resultCategories->num_rows > 0) {
            while ($row = $resultCategories->fetch_assoc()) {
                $categories[] = $row;
            }
        }
    }

}