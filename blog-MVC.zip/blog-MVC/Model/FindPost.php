<?php

class FindPost{


    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function searchPosts($searchTerm) {
        $sql = "
            SELECT 
                posts.id, 
                posts.title, 
                posts.description, 
                posts.date, 
                users.username AS author_name, 
                categories.categories_name AS category_name,
                (SELECT GROUP_CONCAT(tags.tags_name ORDER BY tags.tags_name ASC SEPARATOR ', ') 
                 FROM post_tags 
                 JOIN tags ON post_tags.tag_id = tags.id 
                 WHERE post_tags.post_id = posts.id) AS tag_names
            FROM posts
            JOIN users ON posts.id_author = users.id
            JOIN categories ON posts.categories_id = categories.id
            WHERE 1
        ";

        if ($searchTerm) {
            $sql .= " AND (
                users.username LIKE ? OR 
                posts.title LIKE ? OR 
                posts.description LIKE ? OR 
                categories.categories_name LIKE ? OR 
                EXISTS (
                    SELECT 1
                    FROM post_tags
                    JOIN tags ON post_tags.tag_id = tags.id
                    WHERE post_tags.post_id = posts.id
                    AND tags.tags_name LIKE ?
                )
            )";
        }

        $sql .= " ORDER BY posts.date DESC";

        $stmt = $this->conn->prepare($sql);
        $searchWildcard = "%$searchTerm%";
        if ($searchTerm) {
            $stmt->bind_param('ssssss', $searchWildcard, $searchWildcard, $searchWildcard, $searchWildcard, $searchWildcard);
        } else {
            $stmt->bind_param('sssss', $searchWildcard, $searchWildcard, $searchWildcard, $searchWildcard, $searchWildcard);
        }

        $stmt->execute();
        return $stmt->get_result();
    }
}
?>

