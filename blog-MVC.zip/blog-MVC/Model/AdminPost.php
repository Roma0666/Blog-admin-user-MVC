<?php

class AdminPost
{

    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function getPosts($searchQuery = '', $offset = 0, $records_per_page = 5) {
        $searchQuery = $this->conn->real_escape_string($searchQuery);
        if (!empty($searchQuery)) {
            $sql = "
                SELECT 
                    posts.id,
                    users.username AS author_name,
                    posts.title,
                    posts.description,
                    posts.date,
                    categories.categories_name AS category_name,
                    GROUP_CONCAT(tags.tags_name SEPARATOR ', ') AS tag_names
                FROM 
                    posts
                LEFT JOIN 
                    users ON posts.id_author = users.id
                LEFT JOIN 
                    categories ON posts.categories_id = categories.id
                LEFT JOIN 
                    post_tags ON posts.id = post_tags.post_id
                LEFT JOIN 
                    tags ON post_tags.tag_id = tags.id
                WHERE 
                    posts.title LIKE '%$searchQuery%' OR posts.description LIKE '%$searchQuery%'
                GROUP BY 
                    posts.id
                LIMIT $records_per_page OFFSET $offset
            ";
        } else {
            $sql = "
                SELECT 
                    posts.id,
                    users.username AS author_name,
                    posts.title,
                    posts.description,
                    posts.date,
                    posts.is_moderate,
                    categories.categories_name AS category_name,
                    GROUP_CONCAT(tags.tags_name SEPARATOR ', ') AS tag_names
                FROM 
                    posts
                LEFT JOIN 
                    users ON posts.id_author = users.id
                LEFT JOIN 
                    categories ON posts.categories_id = categories.id
                LEFT JOIN 
                    post_tags ON posts.id = post_tags.post_id
                LEFT JOIN 
                    tags ON post_tags.tag_id = tags.id
                GROUP BY 
                    posts.id
                LIMIT $records_per_page OFFSET $offset
            ";
        }

        return $this->conn->query($sql);
    }

    public function getTotalPostsCount($searchQuery = '') {
        $searchQuery = $this->conn->real_escape_string($searchQuery);
        if (!empty($searchQuery)) {
            $sql = "SELECT COUNT(*) AS total FROM posts WHERE title LIKE '%$searchQuery%' OR description LIKE '%$searchQuery%'";
        } else {
            $sql = "SELECT COUNT(*) AS total FROM posts";
        }

        $result = $this->conn->query($sql);
        $total_row = $result->fetch_assoc();
        return $total_row['total'];
    }

}