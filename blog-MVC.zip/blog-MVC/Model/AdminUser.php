<?php

class AdminUser{
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function getUsers($searchQuery = '', $offset = 0, $records_per_page = 5) {
        if (!empty($searchQuery)) {
            $searchQuery = $this->conn->real_escape_string($searchQuery);
            $sql = "SELECT * FROM users WHERE username LIKE '%$searchQuery%' OR email LIKE '%$searchQuery%' LIMIT $records_per_page OFFSET $offset";
        } else {
            $sql = "SELECT * FROM users LIMIT $records_per_page OFFSET $offset";
        }

        return $this->conn->query($sql);
    }

    public function getTotalUsersCount($searchQuery = '') {
        if (!empty($searchQuery)) {
            $searchQuery = $this->conn->real_escape_string($searchQuery);
            $sql = "SELECT COUNT(*) AS total FROM users WHERE username LIKE '%$searchQuery%' OR email LIKE '%$searchQuery%'";
        } else {
            $sql = "SELECT COUNT(*) AS total FROM users";
        }

        $result = $this->conn->query($sql);
        $total_row = $result->fetch_assoc();
        return $total_row['total'];
    }
}






