<?php

class Contact
{

//    private $con;
//
//    public function __construct($con)
//    {
//        $this->con = $con;
//    }
//
//    public function sendMessage($title, $description)
//    {
//        $stmt = $this->con->prepare("INSERT INTO messages (title, description) VALUES (?, ?)");
//        $stmt->bind_param("ss", $title, $description);
//        return $stmt->execute();
//    }
}