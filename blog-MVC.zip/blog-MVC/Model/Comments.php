<?php
require __DIR__.'/../db.php';
class Comments
{
    public function getPostById(){
        $post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

        if ($post_id) {

            $post_sql = "
        SELECT posts.id, posts.title, posts.description, posts.date, users.username AS author_name 
        FROM posts 
        JOIN users ON posts.id_author = users.id 
        WHERE posts.id = $post_id 
        LIMIT 1
    ";
            $post_result = $conn->query($post_sql);
            $post = $post_result->fetch_assoc();
            return $post;
        }
    }
    public function getComments(){
        if (isset($_GET['post_id'])) {
            $post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

            $comments_sql = "
        SELECT comments.text, comments.date, users.username AS commenter_name 
        FROM comments 
        JOIN users ON comments.id_author = users.id 
        WHERE comments.post_id = $post_id AND comments.is_moderate = 1
        ORDER BY comments.date DESC
    ";
            $comments_result = $conn->query($comments_sql);
            $result = mysqli_query($this->conn, $comments_sql);

            if (!$result) {
                throw new Exception("SQL Error: " . mysqli_error($this->conn));
            }

            return mysqli_fetch_all($result, MYSQLI_ASSOC);
        }
    }
    public function validateComment($comment)
    {
        if (empty($comment)) {
            return "Error: Comment cannot be empty.";
        }
        if (strlen($comment) > 100) {
            return "Error: Comment is too long. Maximum allowed length is 100 characters.";
        }
        if (!preg_match('/^[a-zA-Z0-9\s.,!?]+$/', $comment)) {
            return "Error: Comment can only contain letters, numbers, and basic punctuation.";
        }
        return null;
    }
}




