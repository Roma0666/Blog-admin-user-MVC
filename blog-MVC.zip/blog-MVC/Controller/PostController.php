<?php

require __DIR__ . '/../Model/Post.php';

class PostController
{
    private Post $model;

    public function __construct($conn)
    {
        $this->model = new Post($conn);
    }

    public function index()
    {
        try {
            $posts = $this->model->getAllPosts();
            include __DIR__.'/../View/home.php';
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }
    }
}
