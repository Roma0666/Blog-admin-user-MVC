<?php
require __DIR__."/../Model/Comments.php";
class CommentsController
{
    private $postModel;
    private $commentModel;

    public function __construct()
    {
        $this->postModel = new Comments();
    }

    public function show($post_id)
    {
        $post = $this->postModel->getPostById($post_id);
        $comments = $this->postModel->getComments($post_id);

        include __DIR__.'/../View/comments.php';
    }

    public function addComment($post_id)
    {
        if (!isset($_SESSION['user_id'])) {
            die("User not logged in.");
        }

        $author_id = $_SESSION["user_id"];
        $comment = trim(strip_tags($_POST['comment']));

        $error = $this->commentModel->validateComment($comment);

        if ($error === null) {
            if ($this->postModel->addComment($post_id, $author_id, $comment)) {
                header("Location: /$post_id");
                exit();
            } else {
                $error = "Error: Unable to add comment.";
            }
        }
    }

}