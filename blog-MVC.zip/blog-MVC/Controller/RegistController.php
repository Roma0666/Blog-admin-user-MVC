<?php

class RegistController
{

    public function createAccount()
    {
        require __DIR__ . "/../Model/Regist.php";
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = password_hash($_POST['pass'], PASSWORD_DEFAULT);

            $user = new UserModel($username, $email, $password);
            if ($user->save()) {
                header("Location: success.php");
                exit;
            } else {
                echo "Error creating account.";
            }
        } else {
            $this->showCreateAccountForm();
        }
    }

    private function showCreateAccountForm()
    {
        include(__DIR__.'/../View/regist.php');
    }
}
