<?php
require_once __DIR__.'/../Model/AdminPost.php';
require_once __DIR__.'/../boostrap.php';
class AdminPanelPostController
{
    private $postModel;

    public function __construct($dbConnection) {
        $this->postModel = new AdminPost($dbConnection);
    }

    public function indexAction() {
        $isLoggedIn = isset($_SESSION['user_id']);
        $userRole = isset($_SESSION['role']) ? $_SESSION['role'] : '';

        if ($isLoggedIn && $userRole === 'admin') {
            $records_per_page = 5;
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $offset = ($page - 1) * $records_per_page;

            $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';


            $result = $this->postModel->getPosts($searchQuery, $offset, $records_per_page);
            $total_records = $this->postModel->getTotalPostsCount($searchQuery);
            $total_pages = ceil($total_records / $records_per_page);


            include __DIR__.'/../View/admin-posts.php';
        } else {
            header("Location: index.php");
            exit();
        }
    }
}
