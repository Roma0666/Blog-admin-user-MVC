<?php

class AdminPanelContactController
{
    private $userModel;

    public function __construct($userModel)
    {
        $this->userModel = $userModel;
    }

    public function indexAction()
    {
        if ($this->userModel->isLoggedIn() && $this->userModel->getUserRole() === 'admin') {
            require __DIR__ . '/../View/admin-contact.php';
        } else {
            header("Location: index.php");
            exit();
        }
    }
}