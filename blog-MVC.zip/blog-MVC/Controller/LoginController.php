<?php

class LoginController
{

    public function login()
    {
        require_once (__DIR__.'/../Model/Login.php');
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = $_POST['pass'];

            $user = new UserModel($username, $password);
            if ($user->authenticate()) {
                header("Location: index.php");
                exit;
            } else {
                echo "Invalid credentials.";
            }
        } else {
            $this->showLoginForm();
        }
    }

    private function showLoginForm()
    {
        include(__DIR__.'/../View/login.php');
    }


}