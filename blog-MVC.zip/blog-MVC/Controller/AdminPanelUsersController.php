<?php
require __DIR__.'/../Model/AdminUser.php';

class AdminPanelUsersController
{
    private $userModel;

    public function __construct($dbConnection) {
        $this->userModel = new AdminUser($dbConnection);
    }

    public function indexAction() {
        $isLoggedIn = isset($_SESSION['user_id']);
        $userRole = isset($_SESSION['role']) ? $_SESSION['role'] : '';

        if ($isLoggedIn && $userRole === 'admin') {
            $records_per_page = 5;
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $offset = ($page - 1) * $records_per_page;

            $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

            $result = $this->userModel->getUsers($searchQuery, $offset, $records_per_page);
            $total_records = $this->userModel->getTotalUsersCount($searchQuery);
            $total_pages = ceil($total_records / $records_per_page);

            include __DIR__.'/../View/admin-users.php';
        } else {
            header("Location: index.php");
            exit();
        }
    }
}



