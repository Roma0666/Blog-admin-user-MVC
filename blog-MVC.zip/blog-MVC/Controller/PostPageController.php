<?php
require __DIR__ .'/../Model/PostPage.php';
class PostPageController
{
    private $userModel;

    public function __construct($userModel)
    {
        $this->userModel = $userModel;
    }

    public function indexAction()
    {
        if ($this->userModel->isLoggedIn() && $this->userModel->getUserRole() === 'user') {
            require __DIR__ . '/../View/post-page.php';
        } else {
            header("Location: index.php");
            exit();
        }
    }
}