<?php

class FindPostController{
    private $postModel;

    public function __construct($conn)
    {
        $this->postModel = new FindPostController($conn);
    }

    public function searchAction()
    {
        $searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
        $result = $this->postModel->searchPosts($searchTerm);
        require __DIR__ . '/../Model/FindPost.php';
    }
}

