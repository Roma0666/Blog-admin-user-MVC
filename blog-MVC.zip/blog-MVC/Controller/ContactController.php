<?php
require __DIR__."/../Model/ContactModel.php";
class ContactController
{
    private $userModel;

    public function __construct($userModel)
    {
        $this->userModel = $userModel;
    }

    public function indexAction()
    {
        if ($this->userModel->isLoggedIn() && $this->userModel->getUserRole() === 'user') {
            require __DIR__ . '/../View/contact.php';
        } else {
            header("Location: index.php");
            exit();
        }
    }
}
