<?php
if ($post): ?>
    <div class="post-comm-section">
        <div>
            <img class="user-img" src="img/user.jpg" alt="">
            <?php echo htmlspecialchars($post['author_name']); ?>
        </div>
        <h2><?php echo htmlspecialchars($post['title']); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($post['description'])); ?></p>
        <div><?php echo nl2br(htmlspecialchars($post['date'])); ?></div>
    </div>
    <hr>
    <h3>Comments:</h3>

    <?php while ($comment = $comments->fetch_assoc()): ?>
        <div class="comment">
            <p><strong>
                    <img class="user-img" src="img/user.jpg" alt="">
                    <?php echo htmlspecialchars($comment['commenter_name']); ?>:
                </strong>
                <?php echo nl2br(htmlspecialchars($comment['text'])); ?></p>
            <small><?php echo htmlspecialchars($comment['date']); ?></small>
            <hr>
        </div>
    <?php endwhile; ?>

    <?php if (isset($_SESSION['user_id'])): ?>
        <form method="POST">
            <?php if (isset($error)): ?>
                <div class="error-text"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <textarea name="comment" placeholder="Write your comment..." required pattern="^[a-zA-Z0-9\s.,!?]{10,100}$"></textarea>
            <button class="buttton" type="submit">Post Comment</button>
        </form>
    <?php endif; ?>
<?php else: ?>
    <p class="error-text">Post not found.</p>
<?php endif; ?>
