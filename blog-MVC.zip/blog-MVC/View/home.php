<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Home page</title>
</head>
<body>
<?php require __DIR__.'/../header.php';?>
<div class="main-part-page">
    <div class="post-block">
        <div class="text">Find post</div>
        <form method="get" action="find-post.php">
            <input type="text" placeholder="search" name="search" class="form-find">
            <button type="submit" class="buttton">find</button>
        </form>
    </div>
    <div class="posts-block">
        <?php foreach ($posts as $post): ?>
            <div class="position-posts">
                <div class="post">
                    <div class="post-author">
                        <img class="user-img" src="img/user.jpg" alt=""><?php echo htmlspecialchars($post['username']); ?>
                    </div>
                    <div class="post-title"><?php echo htmlspecialchars($post['title']); ?></div>
                    <div class="post-desc"><?php echo htmlspecialchars($post['description']); ?></div>
                    <div class="post-date"><?php echo htmlspecialchars($post['date']); ?></div>
                    <div><a href="comments.php?post_id=<?php echo htmlspecialchars($post['id']); ?>">comments</a></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require __DIR__. '/../footer.php';?>
</body>
</html>
