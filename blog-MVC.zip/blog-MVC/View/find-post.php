<?php if ($result->num_rows > 0): ?>
    <h2>Results:</h2>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="post find-post">
            <div class="post-author"><img class="user-img" src="img/user.jpg" alt=""><?php echo htmlspecialchars($row['author_name']); ?></div>
            <div class="post-title"><?php echo htmlspecialchars($row['title']); ?></div>
            <div class="post-desc"><?php echo htmlspecialchars($row['description']); ?></div>
            <div class="post-category">Category: <?php echo htmlspecialchars($row['category_name']); ?></div>
            <div class="post-tags">Tags: <?php echo htmlspecialchars($row['tag_names']); ?></div>
            <div class="post-date"><?php echo htmlspecialchars($row['date']); ?></div>
            <div class="post-comments"><a href="comments.php?post_id=<?php echo $row['id']; ?>">View Comments</a></div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>No results found</p>
<?php endif; ?>
