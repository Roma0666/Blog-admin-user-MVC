<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="admin-header">
    <div class="admin-header-item-section">
        <ul>
            <li class="head-admin">Admin Panel</li>
            <li class="item-head-admin"><a href="admin-users.php">Users</a></li>
            <li class="item-head-admin"><a href="admin-posts.php">Posts</a></li>
            <li class="item-head-admin"><a href="admin-categories.php">Categories</a></li>
            <li class="item-head-admin"><a href="admin-comments.php">Comments</a></li>
            <li class="item-head-admin"><a href="admin-tags.php">Tags</a></li>
            <li class="item-head-admin"><a href="admin-contact.php">Contact Support</a></li>
            <li class="item-head-admin"><a href="../logout.php">Logout</a></li>
        </ul>
    </div>
</div>
</body>
</html>
