<?php
include ("header.php");
?>
<link rel="stylesheet" href="style.css">
<title>Static Page</title>
<div class="form">
    <div class="text">Contact form</div>
    <form method="POST" action="send-message.php">
        <input class="form-input" type="text" name="titleMess" placeholder="title" required pattern="^[a-zA-Z0-9\s]{10,100}$" ><br>
        <input class="form-input" type="text" name="descMess" placeholder="desription" required pattern="^[a-zA-Z0-9\s]{10,100}$" ><br>
        <button class="buttton" type="submit">send</button>
    </form>
</div>
<?php
include ("footer.php");
?>
