<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel Users</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="position-admin">
    <div class="admin-header">
        <div class="admin-header-item-section">
            <ul>
                <div class="head-admin">Admin Panel</div>
                <div class="item-head-admin"><li><a href="admin-users.php">Users</a></li></div>
                <div class="item-head-admin"><li><a href="admin-posts.php">Posts</a></li></div>
                <div class="item-head-admin"><li><a href="admin-categories.php">Categories</a></li></div>
                <div class="item-head-admin"><li><a href="admin-comments.php">Comments</a></li></div>
                <div class="item-head-admin"><li><a href="admin-tags.php">Tags</a></li></div>
                <div class="item-head-admin"><li><a href="admin-contact.php">Contact supp</a></li></div>
                <div class="item-head-admin"><li><a href="logout.php">Logout</a></li></div>
            </ul>
        </div>
    </div>

    <div class="position-table">
        <div class="title-table">Users Table</div>
        <a href="create-user.php">Create New User</a>
        <table>
            <tr>
                <th>Id</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Role</th>
                <th>Action</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['id'] . '</td>';
                    echo '<td>' . $row['username'] . '</td>';
                    echo '<td>' . $row['email'] . '</td>';
                    echo '<td>' . $row['pass'] . '</td>';
                    echo '<td>' . $row['role'] . '</td>';
                    echo '<td><a href="delete-user.php?id=' . $row['id'] . '">delete</a> | <a href="update-user.php?id=' . $row['id'] . '">update</a></td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="6">No users found</td></tr>';
            }
            ?>
        </table>

        <div class="pagination">
            <?php
            for ($i = 1; $i <= $total_pages; $i++) {
                echo '<a class="pagination-butt" href="admin-users.php?page=' . $i . ($searchQuery ? '&search=' . $searchQuery : '') . '"';
                if ($i == $page) echo ' class="active"';
                echo '>' . $i . '</a>';
            }
            ?>
        </div>
    </div>
</div>

</body>
</html>
